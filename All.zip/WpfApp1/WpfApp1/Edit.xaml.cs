﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Edit.xaml
    /// </summary>
    public partial class Edit : Window
    {
        private User _user = new User();// создаем нового пользователя
        public Edit(User selectedUser)
        {
            InitializeComponent();
            if(selectedUser!=null)
            {
                _user = selectedUser;
            }
            cmbRole.ItemsSource = kalashnikovEntities.GetContext().Role.ToList();
            DataContext = _user;// для привязок
        }

        private void btnSAVE_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if(string.IsNullOrWhiteSpace(_user.FIO))
            {
                errors.AppendLine("Укажите ФИО");
            }
            if (string.IsNullOrWhiteSpace(_user.Login))
            {
                errors.AppendLine("Укажите логин");
            }
            if (string.IsNullOrWhiteSpace(_user.Password))
            {
                errors.AppendLine("Укажите пароль");
            }
            if(cmbRole.SelectedIndex<0)
            {
                errors.AppendLine("Выберите роль");
            }
            if(errors.Length>0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            if(_user.ID_User==0)
            {
                kalashnikovEntities.GetContext().User.Add(_user);
            }
            
            try
            {
                kalashnikovEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены");
                this.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btnDELETE_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
