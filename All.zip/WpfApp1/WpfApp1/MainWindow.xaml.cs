﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public void Update()
        {
            var users = kalashnikovEntities.GetContext().User.ToList();
            users = users.Where(p => p.FIO.ToLower().Contains(txtPoisk.Text.ToLower()) ||
            p.Role.Title.ToLower().Contains(txtPoisk.Text.ToLower())).ToList();

           if(cbFiltr.SelectedIndex > -1)
            {
                users = users.Where(p => p.Role.Title.Contains(cbFiltr.SelectedItem.ToString())).ToList();
            }

            switch (cbSort.SelectedIndex)//сортировка
            {
                case 0:
                    dataUser.ItemsSource = users.OrderBy(p=>p.FIO);
                    break;
                case 1:
                    dataUser.ItemsSource = users.OrderByDescending(p => p.FIO);
                    break;
                default:
                    dataUser.ItemsSource = users;
                    break;
            }
        }

        public MainWindow()
        {
            InitializeComponent();
            Update();
            var titles = kalashnikovEntities.GetContext().Role.Select(p => p.Title).ToList();
            cbFiltr.ItemsSource = Title;
        }

        private void btnProduct_Click(object sender, RoutedEventArgs e)
        {
            WinTovar win = new WinTovar();
            win.Show();
        }

        private void btnListView_Click(object sender, RoutedEventArgs e)
        {
            List win = new List();
            win.Show();
        }

        private void txtPoisk_TextChanged(object sender, TextChangedEventArgs e)//реальное время
        {
            Update();
        }

        private void Button_Click(object sender, RoutedEventArgs e)//по точному совпадению
        {
            var usersPoisk1 = kalashnikovEntities.GetContext().User.Where(p => p.FIO == txtPoisk1.Text ||
            p.Role.Title == txtPoisk1.Text).ToList();
            dataUser.ItemsSource = usersPoisk1;
        }

        private void cbSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void cbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void btnNewUser_Click(object sender, RoutedEventArgs e)
        {
            Edit win = new Edit(null);
            win.ShowDialog();
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            Update();
        }

        private void btnRed_Click(object sender, RoutedEventArgs e)
        {
            if(dataUser.SelectedIndex>=0)
            {
                Edit win = new Edit(dataUser.SelectedItem as User);
                win.ShowDialog();
            }
            else
            {
                MessageBox.Show("Выделите строку");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var UserDelete = dataUser.SelectedItems.Cast<User>().ToList();
            if (MessageBox.Show("Вы действительно хотите удалить элемент?","Венимение!",
                MessageBoxButton.YesNo,MessageBoxImage.Warning)==MessageBoxResult.Yes)
            {
                try
                {
                    kalashnikovEntities.GetContext().User.RemoveRange(UserDelete);
                    kalashnikovEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалины", "Сообщение!");
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Абубандит");
        }

        private void btnRed_SingIn_Click(object sender, RoutedEventArgs e)
        {
            WinSingIn win = new WinSingIn();
            win.ShowDialog();
        }
    }
}
