﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для WinSingIn.xaml
    /// </summary>
    public partial class WinSingIn : Window
    {
        public WinSingIn()
        {
            InitializeComponent();
        }

        private void btnSintInAcc_Click(object sender, RoutedEventArgs e)
        {
            var users = kalashnikovEntities.GetContext().User.ToList();
            var user = users.Find(p=>p.Login==txtLogin.Text && p.Password == txtPassword.Password);
            if(user != null)
            {
                MessageBox.Show("Все оки-доки, проходи","АУФ, МЫ УКАТЫВАЕМ СО ДВОРОВ"); 
                switch(user.ID_Role)
                {
                    case 1:
                        WinUser winAdmin = new WinUser();
                        winAdmin.Title = "Администратор";
                        winAdmin.lbNameUser.Content = "Вы зашли как " + user.FIO;
                        winAdmin.ShowDialog();
                        break;
                    case 2:
                        WinUser winManeger = new WinUser();
                        winManeger.Title = "Менеджер";
                        winManeger.lbNameUser.Content = "Вы зашли как " + user.FIO;
                        winManeger.ShowDialog();
                        break;
                    case 3:
                        WinUser winClient = new WinUser();
                        winClient.Title = "Клиент";
                        winClient.lbNameUser.Content = "Вы зашли как " + user.FIO;
                        winClient.ShowDialog();
                        break;
                }
            }
            else MessageBox.Show("Все НЕ оки-доки, оставайся", "АУФ, МЫ НЕ УКАТЫВАЕМ СО ДВОРОВ");
        }

        private void btnRegAcc_Click(object sender, RoutedEventArgs e)
        {
            WindowRegistr winReg = new WindowRegistr();
            winReg.ShowDialog();
        }
    }
}
