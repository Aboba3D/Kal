﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для WindowRegistr.xaml
    /// </summary>
    public partial class WindowRegistr : Window
    {
        public WindowRegistr()
        {
            InitializeComponent();
        }

        private void btnRegAcc_Click(object sender, RoutedEventArgs e)
        {
            
            var users = kalashnikovEntities.GetContext().User.ToList();
            var user = users.Find(p => p.Login != txtLogin.Text && p.Password != txtPassword.Password);
            if (user != null)
            {
                if (cmbRole.SelectedIndex > -1)
                {
                    if(cmbRole.SelectedIndex==0)
                    {
                    }
                MessageBox.Show("Аккаунт создан", "АУФ, МЫ УКАТЫВАЕМ СО ДВОРОВ");                                             
                WinUser winClient = new WinUser();
                winClient.Title = "Клиент";
                winClient.lbNameUser.Content = "Вы зашли как " + user.FIO + "твоя роль" + user.ID_Role;
                winClient.ShowDialog();
                }            
            }
            else MessageBox.Show("Такой аккаунт уже существует", "АУФ, МЫ НЕ УКАТЫВАЕМ СО ДВОРОВ");
        }
    }
}

