﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR10_Authorization_
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void btn_Autorization_Click(object sender, RoutedEventArgs e)
        {
            var users = SotrudnikiEntities.GetContext().user.ToList();
            var user = users.Find(p => p.login == TBLogin.Text && p.password == txtPassword.Password);
            if (user != null)
            {
                MessageBox.Show("Добро пожаловать!", "Успешно!", MessageBoxButton.OK, MessageBoxImage.Information);
                switch (user.id_role)
                {
                    case 1:
                        Wins.WinUserAdmin winUserAdmin = new Wins.WinUserAdmin();
                        winUserAdmin.Title = "Администратор";
                        winUserAdmin.LBUser.Content = "Добро пожаловать!";
                        winUserAdmin.LBLogin.Content = "Вы зашли под логином: " + user.login;
                        winUserAdmin.LBRole.Content = "Вы зашли под ролью: Администратор";
                        winUserAdmin.Show();
                        break;

                    case 2:
                        Wins.WinUserManager winUserManager = new Wins.WinUserManager();
                        winUserManager.Title = "Менеджер";
                        winUserManager.LBUser.Content = "Добро пожаловать!";
                        winUserManager.LBLogin.Content = "Вы зашли под логином: " + user.login;
                        winUserManager.LBRole.Content = "Вы зашли под ролью: Менеджер";
                        winUserManager.Show();
                        break;
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("Пользователь не найден!");
            }
        }

        private void btn_Registr_Click(object sender, RoutedEventArgs e)
        {
            Wins.WinReg winReg = new Wins.WinReg(null);
            winReg.ShowDialog();
        }
    }
}
