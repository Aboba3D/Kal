﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace PR10_Authorization_.Wins
{
    /// <summary>
    /// Логика взаимодействия для WinReg.xaml
    /// </summary>
    public partial class WinReg : Window
    {
        private user _user = new user();//Создаём нового пользователя
        public WinReg(user selectedUser)
        {
            InitializeComponent();
            if (selectedUser != null)
            {
                _user = selectedUser;
            }
            CBRole.ItemsSource = SotrudnikiEntities.GetContext().role.ToList();
            DataContext = _user;//Для привязок
        }

        private void BTNReg_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_user.login))
            {
                errors.AppendLine("Укажите Логин");
            }
            if (string.IsNullOrWhiteSpace(_user.password))
            {
                errors.AppendLine("Укажите Пароль");
            }
            if (string.IsNullOrWhiteSpace(_user.mail))
            {
                errors.AppendLine("Укажите Эл.Почту");
            }
            if (_user.password.Length < 6)
            {
                errors.AppendLine("Пароль должен содержать минимум 6 символов.");
            }

            if (!Regex.IsMatch(_user.password, "[A-Z]"))
            {
                errors.AppendLine("Пароль должен содержать минимум 1 прописную букву.");
            }

            if (!Regex.IsMatch(_user.password, @"\d"))
            {
                errors.AppendLine("Пароль должен содержать минимум 1 цифру.");
            }

            if (!Regex.IsMatch(_user.password, "[!@#$%^]"))
            {
                errors.AppendLine("Пароль должен содержать минимум один символ из набора: ! @ # $ % ^.");
            }


            if (CBRole.SelectedIndex < 0)//Проверка заполнения ComboBox'а
            {
                errors.AppendLine("Выберите Роль");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_user.id_user == 0)
            {
                SotrudnikiEntities.GetContext().user.Add(_user);
            }

            try
            {
                SotrudnikiEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены!", "Успешно!", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }



            if (CBRole.SelectedIndex < 0)//Проверка заполнения ComboBox'а
            {
                errors.AppendLine("Выберите Роль");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_user.id_user == 0)
            {
                SotrudnikiEntities.GetContext().user.Add(_user);
            }

            try
            {
                SotrudnikiEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены!", "Успешно!", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
