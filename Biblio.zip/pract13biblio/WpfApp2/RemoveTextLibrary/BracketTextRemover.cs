﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace RemoveTextLibrary
{
    public class BracketTextRemover
    {
        public static string RemoveTextInBrackets(string input)
        {         
            return Regex.Replace(input, @"\s*\([^()]*\)",string.Empty);
        }
    }
}

