﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainglePerandSqLibrary
{
    public class Traingle
    {
       public double sideB { get; set; }
       public double sideA { get; set; }
       public double n { get; set; }

        //double b = n * a / 100;
        // double area = a * b;
        //double perimeter = 2 * (a + b);
        public double GetB()
        {
            return n * sideA / 100;
        }

        public double GetS()
        {
            return sideA * sideB;
        }

        public double GetP()
        {
            return 2 * (sideA + sideB);
        }
    }
}
