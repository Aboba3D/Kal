﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnExcel_Click(object sender, RoutedEventArgs e)
        {
            //Создание Excel приложения
            var app = new Excel.Application();
            Excel.Workbook workbook = app.Workbooks.Add(Type.Missing);
            Excel.Worksheet worksheet1 = app.Worksheets[1];
            worksheet1.Name = "Третий";
            Excel.Worksheet worksheet2 = app.Worksheets.Add();
            worksheet2.Name = "Второй";
            Excel.Worksheet worksheet3 = app.Worksheets.Add();
            worksheet3.Name = "Первый";

            worksheet3.Range["A1"].Value = "Привет"; // В одну ячейку
            worksheet3.Range["A1"].Font.Bold = true;
            worksheet3.Range["A1"].Font.Italic = true;
            worksheet3.Range["A1"].Font.Size = 23;
            worksheet3.Range["A1"].Font.Color=255;
            worksheet3.Range["A1"].Borders.LineStyle=Excel.XlLineStyle.xlContinuous;

            worksheet3.Range["A2:D2"].Value = "Пока"; // В диапозон
            worksheet3.Range["A3"].Value = DateTime.Now;

            worksheet3.Range["A4"].Value = 10;
            worksheet3.Range["A5"].Value = 8;
            worksheet3.Range["A6"].Formula =$"=SUM($A4+$A5)";

            for(int i = 1;i<=10;i++)
            {
                worksheet3.Range["E" + i].Value = i * 2;
            }

            var points = kalashnikovEntities.GetContext().Pick_UP_Point.ToList();

            worksheet2.Range["A3"].Value = "№ пп";
            worksheet2.Range["B3"].Value = "Адрес пункта выдачи";
            worksheet2.Range["A3:B3"].Font.Bold = true;
            for(int i  = 4;i<=points.Count()+3;i++)
            {
                worksheet2.Range["A"+i].Value = i-3;
            }

            int j = 4;

            foreach(var p in points)
            {
                worksheet2.Range["B" + j].Value = p.Address;
                j++;
            }

            worksheet2.Range["A1"].Value = "Список пунктов выдачи";
            worksheet2.Range["A1"].Font.Bold = true;
            worksheet2.Range["A1"].Font.Size = 35;

            //Всегда внизу
            worksheet3.Columns.AutoFit();
            worksheet2.Columns.AutoFit();
            app.Visible=true;
        }
    }
}
