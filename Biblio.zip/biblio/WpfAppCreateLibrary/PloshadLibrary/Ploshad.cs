﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PloshadLibrary
{
    public class Ploshad
    {
        public int Dlina { get; set; }
        public int Shirina { get; set; }

        public int GetPloshad()
        {
            return Dlina * Shirina;
        }
    }
}
