﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumLibrary
{
    public class Sum
    {
        public int Chislo1 { get; set; }
        public int Chislo2 { get; set; }

        public int GetSum()
        {
            return Chislo1 + Chislo2;
        }
    }
}
