﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public void UpDate()
        {
            var NamePoisk = rudEntities.GetContext().Materials.ToList();
            NamePoisk = NamePoisk.Where(p => p.Name.ToLower().Contains(txtPoisk.Text.ToLower())).ToList();
            ListMat.ItemsSource = NamePoisk;

        }
        public Window1()
        {
            InitializeComponent();
            UpDate();
            var NamePoisk = rudEntities.GetContext().Materials.ToList();
            ListMat.ItemsSource = NamePoisk;
            rbDEF.IsChecked = true;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpDate();
        }

        private void rbINC_Checked(object sender, RoutedEventArgs e)
        {
            var NamePoisk = rudEntities.GetContext().Materials.ToList();
            ListMat.ItemsSource = NamePoisk.OrderBy(p => p.Name);
        }

        private void rbDEC_Checked(object sender, RoutedEventArgs e)
        {
            var NamePoisk = rudEntities.GetContext().Materials.ToList();
            ListMat.ItemsSource = NamePoisk.OrderByDescending(p => p.Name);
        }

        private void rbDEF_Checked(object sender, RoutedEventArgs e)
        {
            var NamePoisk = rudEntities.GetContext().Materials.ToList();
            ListMat.ItemsSource = NamePoisk;
        }
    }
}
