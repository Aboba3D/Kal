﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;


namespace pract11
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var Orders = SotrudnikiEntities.GetContext().orders.ToList();
            dataOrders.ItemsSource = Orders;
        }

        private void btnExcel_Click(object sender, RoutedEventArgs e)
        {
            var app = new Excel.Application();
            Excel.Workbook workbook = app.Workbooks.Add(Type.Missing);
            Excel.Worksheet worksheet1 = app.Worksheets[1];
            worksheet1.Name = "Это практика 12";
            worksheet1.Range["A1"].Value = "Отчет заказов";
            worksheet1.Range["A1"].Font.Size = 20;
            worksheet1.Range["A1"].Font.Bold = true;
            var order = SotrudnikiEntities.GetContext().orders.ToList();
            worksheet1.Range["B2"].Value = "Получатель";
            worksheet1.Range["B2"].Value = "Код";
            worksheet1.Range["C2"].Value = "Цена";
            worksheet1.Range["A1"].Font.Bold = true;
            worksheet1.Range["A2:C8"].Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

            int j = 3;

            foreach (var p in order)
            {
                worksheet1.Range["A" + j].Value = p.fio_poluchat;
                worksheet1.Range["B" + j].Value = p.kod;
                worksheet1.Range["C" + j].Value = p.Cost;
                j++;
            }

            worksheet1.Range["B7"].Value = "Итог:";
            worksheet1.Range["C7"].Formula = $"=SUM(C3:C6)";
            worksheet1.Range["B8"].Value = "Ср.знач:";
            worksheet1.Range["C8"].Formula = $"=AVERAGE(C3:C6)";

            worksheet1.Columns.AutoFit();
            app.Visible = true;

        }
    }
}
