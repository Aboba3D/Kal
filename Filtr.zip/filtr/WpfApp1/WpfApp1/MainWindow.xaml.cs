﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Update();
            var titles = kalashnikovEntitiess.GetContext().Type_Material.Select(p => p.Title_TypeMaterial).ToList();
            cb_filt.ItemsSource = titles;
        }
        public void Update()
        { 
            var Product = kalashnikovEntitiess.GetContext().Materials.ToList();
            Product = Product.Where(p => p.Name.ToLower().Contains(tb_real_time.Text.ToLower())).ToList();
            if (cb_filt.SelectedIndex > -1)
            {
                Product = Product.Where(p => p.Type_Material.Title_TypeMaterial.Contains(cb_filt.SelectedItem.ToString())).ToList();
            }
            switch (cb_price.SelectedIndex)
            {
                case 0: dg_material.ItemsSource = Product.Where(p => p.Price > 100).ToList(); break;
                case 1: dg_material.ItemsSource = Product.Where(p => p.Price > 1000).ToList(); break;
                default: dg_material.ItemsSource = Product; break;
            }
            switch (cb_qaleti.SelectedIndex)
            {
                case 0: dg_material.ItemsSource = Product.Where(p => p.Count_in_stock < 10).ToList(); break;
                case 1: dg_material.ItemsSource = Product.Where(p => p.Count_in_stock > 100).ToList(); break;
                default: dg_material.ItemsSource = Product; break;
            }
           
           
        }

        private void tb_real_time_TextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void rb_ybivani_Checked(object sender, RoutedEventArgs e)
        {
            var namepoisk = kalashnikovEntitiess.GetContext().Materials.ToList();
            dg_material.ItemsSource = namepoisk.OrderByDescending(p => p.Name);
        }

        private void rb_vozrostanie_Checked(object sender, RoutedEventArgs e)
        {
            var namepoisk = kalashnikovEntitiess.GetContext().Materials.ToList();
            dg_material.ItemsSource = namepoisk.OrderBy(p => p.Name);
        }

        private void cb_filt_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void cb_price_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void cb_qaleti_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void btn_sbros_Click(object sender, RoutedEventArgs e)
        {
            cb_filt.SelectedIndex = -1;
            cb_price.SelectedIndex = -1;
            cb_qaleti.SelectedIndex = -1;
            rb_vozrostanie.IsChecked = false;
            rb_ybivani.IsChecked = false;
            tb_real_time.Text = "";
            Update();
        }
    }
}
