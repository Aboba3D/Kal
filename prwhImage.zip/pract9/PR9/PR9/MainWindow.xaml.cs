﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Win32;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR9
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private sotrudniki _sotrydnik = new sotrudniki();

        public MainWindow()
        {
            InitializeComponent();
            Update();
            DataContext = _sotrydnik;
        }

        public void Update()
        {
            var search = SotrudnikiEntities.GetContext().sotrudniki.ToList();
            search = search.Where(p => p.name.ToLower().Contains(TBSearch.Text.ToLower())).ToList();
            dataSotrydniki.ItemsSource = search;
        }

        private void TBSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            var sotrydnikiDelete = dataSotrydniki.SelectedItems.Cast<sotrudniki>().ToList();
            if (MessageBox.Show("Вы точно хотите удалить элементы?", "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                try
                {
                    SotrudnikiEntities.GetContext().sotrudniki.RemoveRange(sotrydnikiDelete);
                    SotrudnikiEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!", "Успешно!", MessageBoxButton.OK, MessageBoxImage.Information);
                    Update();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BTNAdd_Click(object sender, RoutedEventArgs e)
        {
            TBFIO.IsEnabled = true;
            TBPhone.IsEnabled = true;
            TBRole.IsEnabled = true;
            BTNImage.IsEnabled = true;
            BTNAdd.IsEnabled = false;
            BTNSave.IsEnabled = true;
        }

        private void BTNSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_sotrydnik.name))
            {
                errors.AppendLine("Укажите ФИО");
            }
            if (string.IsNullOrWhiteSpace(_sotrydnik.phone))
            {
                errors.AppendLine("Укажите Телефон");
            }
            if (string.IsNullOrWhiteSpace(_sotrydnik.role))
            {
                errors.AppendLine("Укажите Роль");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_sotrydnik.ID == 0)
            {
                SotrudnikiEntities.GetContext().sotrudniki.Add(_sotrydnik);
            }

            try
            {
                SotrudnikiEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены!", "Успешно!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

            Update();

            TBFIO.IsEnabled = default;
            TBPhone.IsEnabled = default;
            TBRole.IsEnabled = default;

            TBFIO.Text = default;
            TBPhone.Text = default;
            TBRole.Text = default;

            BTNImage.IsEnabled = default;
            BTNAdd.IsEnabled = true;
            BTNSave.IsEnabled = default;

            ImgDisplay.Source = null;
        }

        private void BTNEdit_Click(object sender, RoutedEventArgs e)
        {
            BTNEdit.IsEnabled = false;
            BTNAdd.IsEnabled = false;
            BTNSave.IsEnabled = false;

            BTNUpdate.IsEnabled = true;
            BTNImage.IsEnabled = true;

            TBFIO.IsEnabled = true;
            TBPhone.IsEnabled = true;
            TBRole.IsEnabled = true;

            if (dataSotrydniki.SelectedIndex > -1)
            {
                _sotrydnik = dataSotrydniki.SelectedItem as sotrudniki;
                TBFIO.Text = _sotrydnik.name;
                TBPhone.Text = _sotrydnik.phone;
                TBRole.Text = _sotrydnik.role;
            }
        }

        private void dataSotrydniki_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataSotrydniki.SelectedItem != null)
            {
                BTNEdit.IsEnabled = true;
            }
            else BTNEdit.IsEnabled = false;
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            Update();
        }

        private void BTNUpdate_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_sotrydnik.name))
            {
                errors.AppendLine("Укажите ФИО");
            }
            if (string.IsNullOrWhiteSpace(_sotrydnik.phone))
            {
                errors.AppendLine("Укажите Телефон");
            }
            if (string.IsNullOrWhiteSpace(_sotrydnik.role))
            {
                errors.AppendLine("Укажите Роль");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_sotrydnik.ID == 0)
            {
                SotrudnikiEntities.GetContext().sotrudniki.Add(_sotrydnik);
            }

            if (_sotrydnik.ID > 0)
            {
                _sotrydnik.name = TBFIO.Text;
                _sotrydnik.phone = TBPhone.Text;
                _sotrydnik.role = TBRole.Text;
            }

            try
            {
                SotrudnikiEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены!", "Успешно!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

            Update();

            TBFIO.IsEnabled = default;
            TBPhone.IsEnabled = default;
            TBRole.IsEnabled = default;

            TBFIO.Text = default;
            TBPhone.Text = default;
            TBRole.Text = default;

            BTNImage.IsEnabled = default;
            BTNAdd.IsEnabled = true;
            BTNEdit.IsEnabled = default;
            BTNUpdate.IsEnabled = default;

            ImgDisplay.Source = null;
        }

        private void BTNImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif|All files|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;

                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(filePath);
                bitmap.EndInit();

                ImgDisplay.Source = bitmap;
            }
        }
    }
}
